#puts "What is your first name? "
#firstname = gets.chomp
#puts "Hello " + firstname + ", what is your last name?"
#lastname = gets.chomp
#puts "Hello " + firstname + " " + lastname + ", welcome."

# puts "Enter a number: "
# input = gets.chomp
# puts "You entered " + input
# puts input.to_i * 3

# def multiply(firstnum, secondnum)
#     firstnum.to_f * secondnum.to_f
# end

# puts "Enter some numbers "
# firstnumber = gets.chomp
# secondnumber = gets.chomp

# puts multiply(firstnumber, secondnumber)

# yes = false
# no = false
# if yes == false && no == false
#     puts "Hello"
# else
#     puts "Bye"
# end

# a = [1,2,3,4,5]
# x = "a".."z"
# puts a.shuffle.join("-")
# puts a.join(", ")
# print x

a = [1, 2, 3, 4, 5]
b = ["My", "name", "is", "Jak"]
# for i in a
#     print a
# end

# b.each do |food|
#     print food + " "
# end 
# b.each {|food| print food.capitalize + " "}

c = (1..100).to_a
print c.select {|number| number}
#print c.select {|number| number.odd?}




