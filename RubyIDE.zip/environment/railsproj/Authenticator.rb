users = [
    {username: "Jak", password: "password1"},
    {username: "Jack", password: "password2"}
    ]
puts "Welcome to authenticator"
20.times{print "_"}
puts
puts "This program gets user and password"
loggedin = 0
attempts = 0

def auth_user(username, pass, listusers)
        listusers.each do |userz|
        
        if userz[:username] == username && userz[:password] == pass
            puts "You logged in"
            return userz
        end
    end
    p "Wrong Info"
end

while attempts < 2
    p "Enter User: "
    username = gets.chomp
    puts
    p "Enter Password: "
    pass = gets.chomp
    authentication = auth_user(username, pass, users)
    break if loggedin == 1
    puts authentication
    puts "type esc to quit"
    esc = gets.chomp
    break if esc == "esc"
    # users.each do |userz|
        
    #     if userz[:username] == user && userz[:password] == pass
    #         puts "You logged in"
    #         loggedin = 1
    #         break
    #     else
    #         puts "Wrong info"
    #         attempts += 1
    #     end
    # end
    attempts += 1
end