class Student
    attr_accessor :first_name, :last_name, :email, :username
    #attr_reader :username
    def initialize(firstname, lastname, user, email, password)
        @first_name = firstname
        @last_name = lastname
        @username = user
        @email = email
        @password = password
    end
    # def first_name(name)
    #     @first_name = name
    # end
    # # def last_name(name)
    # #     @last_name = name
    # # end
    
    def to_s
      "First name: #{@first_name}, last_name: #{@last_name}" 
    end
    
    
    
end

jack = Student.new("Jack", "Huynh", "JAK", "Jack@EMAIL", "Passw1")
# jack.first_name = "Jack"
# jack.last_name = "Huynh"
# jack.email = "jack@email.com"
# #jack.username = "JAK"
# puts jack.first_name
# puts jack.last_name
# puts jack.email
# puts jack.username
puts jack