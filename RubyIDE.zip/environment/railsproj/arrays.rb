# a = [1, 2, 3, 4, 5]
# b = a
# until a.empty? #pops until empty
#     puts a.pop
# end


#Hash

sample_hash = {'a' => 1, 'b' => 2, 'c' => 3}
p sample_hash['b']
another_hash = {a: 4, b: 5, c: 6}
p another_hash[:c]

sample_hash.each do |key, value|
    p key
    p value
end 