#puts "Hello Ruby"
#p "Hello Ruby"
#print "Hello Rwby"

HelloWorld = "Hello World my name is Jack"
puts HelloWorld

firstname = "Jack"
lastname = "huynh"

puts firstname + " " + lastname